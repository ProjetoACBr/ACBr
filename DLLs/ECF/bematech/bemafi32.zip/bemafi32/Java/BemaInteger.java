package bemajava;


public class BemaInteger {
	public int number;
	
	public BemaInteger()
	{
		number = 0;
	
	}
	public int getNumber(){
		return number;
	}
}
